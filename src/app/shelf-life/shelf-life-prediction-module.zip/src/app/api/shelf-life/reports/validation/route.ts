import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { validateSampleDates } from "@/app/shelf-life/lib/validation";
import { validatePredictionAgainstSample } from "@/app/shelf-life/lib/prediction";
import { mae, rmse, bias } from "@/app/shelf-life/lib/statistics";

export async function GET(req: NextRequest) {
  try {
    // 1. Data quality issues
    const allSamples = await prisma.shelfLifeSample.findMany({
      select: {
        id: true,
        sampleId: true,
        variety: true,
        pickDate: true,
        packDate: true,
        pickTemp: true,
        brix: true,
        packWeight: true,
        status: true,
        totalDays: true,
      },
    });

    const issues: Array<{
      sampleId: string;
      type: "error" | "warning";
      message: string;
    }> = [];

    allSamples.forEach((s) => {
      // Date validation
      const dateValidation = validateSampleDates(s.pickDate, s.packDate);
      dateValidation.errors.forEach((msg) =>
        issues.push({ sampleId: s.sampleId, type: "error", message: msg })
      );
      dateValidation.warnings.forEach((msg) =>
        issues.push({ sampleId: s.sampleId, type: "warning", message: msg })
      );

      // Missing critical fields
      if (s.pickTemp === null) {
        issues.push({ sampleId: s.sampleId, type: "warning", message: "Missing pick temperature" });
      }
      if (s.brix === null) {
        issues.push({ sampleId: s.sampleId, type: "warning", message: "Missing Brix" });
      }
      if (s.packWeight === null && s.status !== "FAILED") {
        issues.push({ sampleId: s.sampleId, type: "warning", message: "Missing pack weight" });
      }

      // Suspicious values
      if (s.pickTemp !== null && (s.pickTemp < 5 || s.pickTemp > 50)) {
        issues.push({
          sampleId: s.sampleId,
          type: "warning",
          message: `Suspicious pick temperature: ${s.pickTemp}°C`,
        });
      }
      if (s.brix !== null && (s.brix < 3 || s.brix > 30)) {
        issues.push({
          sampleId: s.sampleId,
          type: "warning",
          message: `Suspicious Brix: ${s.brix}`,
        });
      }
    });

    // 2. Model validation (predicted vs actual for failed samples with complete data)
    const failedWithData = allSamples.filter(
      (s) =>
        s.status === "FAILED" &&
        s.pickTemp !== null &&
        s.brix !== null &&
        s.totalDays !== null &&
        s.totalDays > 0
    );

    const validations = [];
    for (const sample of failedWithData.slice(0, 50)) {
      const result = await validatePredictionAgainstSample(sample.id);
      if (result && result.error !== null) {
        validations.push(result);
      }
    }

    const predicted = validations.map((v) => v.predictedShelfLife!);
    const actual = validations.map((v) => v.actualShelfLife!);

    const metrics = {
      mae: mae(predicted, actual),
      rmse: rmse(predicted, actual),
      bias: bias(predicted, actual),
      count: validations.length,
    };

    return NextResponse.json({
      dataQuality: {
        totalSamples: allSamples.length,
        issues,
        issueCount: issues.length,
      },
      modelValidation: {
        metrics,
        samples: validations,
      },
    });
  } catch (error) {
    console.error("GET validation report error:", error);
    return NextResponse.json(
      { error: "Failed to generate validation report" },
      { status: 500 }
    );
  }
}
