# Shelf-Life Prediction Module — Implementation Guide

## What was built

### Shared Utilities (`src/app/shelf-life/lib/`)

| File | Purpose |
|------|---------|
| `prediction.ts` | **The Shelf-Life Engine**. `predictShelfLife()` combines quality model + weight model → combined prediction with confidence, risk, and explanation. Also includes `validatePredictionAgainstSample()` for model validation. |
| `risk.ts` | Risk classification (`LOW`/`MODERATE`/`HIGH`/`INSUFFICIENT_DATA`), confidence levels, approaching-failure logic. |
| `weight-curve.ts` | Weight curve utilities: `getWeightCurve()`, `calculateWeightShelfLife()`, `interpolateWeightLoss()`. |
| `temperature.ts` | Temperature range lookup, temp adjustment factors, temp impact queries. |
| `validation.ts` | Input validation (`validatePredictionInputs`), date validation, weight reading anomaly detection. |
| `statistics.ts` | Mean, median, percentile, stdDev, MAE, RMSE, bias, interpolation utilities. |

### New API Routes

| Route | Description |
|-------|-------------|
| `GET /api/shelf-life/predict/shelf-life` | **Core prediction API**. Params: `variety`, `pickTemp`, `brix`, `freightType`, `week`, `packWeight`. Returns full prediction with confidence, risk, weight projection, warnings, and explanation. |
| `GET /api/shelf-life/reports/validation` | Data quality audit + model validation (predicted vs actual for failed samples). Returns MAE, RMSE, bias, and per-sample errors. |

### New Components

| Component | Use In | Description |
|-----------|--------|-------------|
| `ShelfLifePredictionCard` | `predictions/page.tsx`, `[id]/page.tsx` | Full prediction display: predicted/recommended/limiting factor cards, risk at 14/30 days, input summary, warnings, explanation breakdown. |
| `MarkAsFailedDialog` | `[id]/page.tsx` | Confirmation dialog with failure day, reason, notes. Calls `PATCH /api/shelf-life/samples/[id]`. |
| `SampleStatusHeader` | `[id]/page.tsx` | Header showing sample info, day progress bar, remaining days, risk level, recommended shelf life. |
| `PredictionVsActual` | `reports/page.tsx` | Scatter chart of predicted vs actual shelf life for model validation. |
| `VarietyIntelligenceTable` | `reports/page.tsx` | Table of all varieties with performance stats, risk badges, overpack %. Highlights best/worst. |
| `DataQualityPanel` | `reports/page.tsx` | Shows data quality issues (errors/warnings) from the validation API. |

## Architecture

```
HISTORICAL DATA
      │
      ├── Quality Model (TIME_TEMP + RETENTION failures)
      │   → median failure day per variety
      │   → temp-adjusted, brix-adjusted
      │   → conservative P25 estimate
      │
      ├── Weight Model (WEIGHT_RETENTION curves)
      │   → variety-specific 40-day predicted curves
      │   → day to 5% loss = weight shelf life
      │
      └── Temperature Impact (temp bins)
          → adjustment factor per temp range

              ↓
       SHELF-LIFE ENGINE (predictShelfLife)
              ↓
       MIN(quality_limit, weight_limit)
              ↓
       predictedShelfLife − safety_margin
              ↓
       recommendedShelfLife
              ↓
       ┌─────────────┬─────────────┐
       ▼             ▼             ▼
   Risk Level   Overpack     Shipment
   (display)    Decision     Decision
```

## Integration into existing pages

### 1. `src/app/shelf-life/page.tsx` (Dashboard)

Add these imports and logic:

```tsx
import { SampleStatsCards, StatusBadge } from "./components";
import { classifyRisk } from "./lib/risk";

// Fetch samples
const samples = await fetch("/api/shelf-life/samples").then(r => r.json());

// For each active sample, compute derived status
function getDisplayStatus(sample) {
  if (sample.status === "FAILED") return "FAILED";
  if (sample.status === "COMPLETED") return "COMPLETED";
  // If you have prediction data cached, use it:
  // const remaining = predictedShelfLife - currentDay;
  // if (remaining <= 2) return "APPROACHING";
  return "ACTIVE";
}

// Stats
const activeCount = samples.filter(s => s.status === "ACTIVE").length;
const failedThisWeek = samples.filter(s => s.status === "FAILED").length;
const avgShelfLife = samples.length > 0
  ? samples.reduce((a, s) => a + (s.totalDays || 0), 0) / samples.length
  : 0;
```

### 2. `src/app/shelf-life/[id]/page.tsx` (Sample Detail)

```tsx
"use client";
import { useEffect, useState } from "react";
import {
  DailyTrackingForm,
  WeightLossChart,
  DefectChart,
  ShelfLifePredictionCard,
  MarkAsFailedDialog,
  SampleStatusHeader,
  PredictionVsActual,
  StatusBadge,
} from "../components";
import { classifyRisk } from "../lib/risk";

export default function SampleDetailPage({ params }: { params: { id: string } }) {
  const [sample, setSample] = useState(null);
  const [prediction, setPrediction] = useState(null);
  const [refresh, setRefresh] = useState(0);

  useEffect(() => {
    fetch(`/api/shelf-life/samples/${params.id}`)
      .then(r => r.json())
      .then(data => {
        setSample(data);
        // Get prediction for this sample
        if (data.pickTemp && data.brix) {
          fetch(`/api/shelf-life/predict/shelf-life?` +
            `variety=${data.variety}&pickTemp=${data.pickTemp}&brix=${data.brix}` +
            `&freightType=${data.freightType || "AIR"}`)
            .then(r => r.json())
            .then(setPrediction);
        }
      });
  }, [params.id, refresh]);

  if (!sample) return <div>Loading...</div>;

  const existingDays = [
    ...new Set([
      ...sample.observations.map(o => o.day),
      ...sample.weightReadings.map(w => w.day),
    ]),
  ].sort((a, b) => a - b);

  const currentDay = existingDays.length > 0 ? Math.max(...existingDays) : 0;

  // Compute risk from prediction
  const riskInfo = prediction?.predictedShelfLife
    ? classifyRisk(currentDay, prediction.predictedShelfLife, prediction.confidence)
    : null;

  return (
    <div className="space-y-6 p-6 max-w-6xl mx-auto">
      {/* Header */}
      <SampleStatusHeader
        sample={sample}
        prediction={riskInfo ? { ...riskInfo, predictedShelfLife: prediction.predictedShelfLife } : null}
        currentDay={currentDay}
      />

      {/* Prediction */}
      {prediction && (
        <ShelfLifePredictionCard prediction={prediction} />
      )}

      {/* Daily Tracking */}
      <div className="bg-white border rounded-xl p-5 shadow-sm">
        <h2 className="text-lg font-semibold mb-4">Daily Tracking</h2>
        <DailyTrackingForm
          sampleId={sample.id}
          sampleType={sample.sampleType}
          packWeight={sample.packWeight}
          existingDays={existingDays}
          onSave={() => setRefresh(r => r + 1)}
        />
      </div>

      {/* Charts */}
      {sample.weightReadings.length > 0 && (
        <div className="bg-white border rounded-xl p-5 shadow-sm">
          <h2 className="text-lg font-semibold mb-4">Weight Loss</h2>
          <WeightLossChart
            readings={sample.weightReadings}
            predictedCurve={sample.weightCurve || []}
          />
        </div>
      )}

      {sample.observations.length > 0 && (
        <div className="bg-white border rounded-xl p-5 shadow-sm">
          <h2 className="text-lg font-semibold mb-4">Defect Progression</h2>
          <DefectChart observations={sample.observations} />
        </div>
      )}

      {/* Prediction vs Actual (for failed samples) */}
      {sample.status === "FAILED" && (
        <div className="bg-white border rounded-xl p-5 shadow-sm">
          <h2 className="text-lg font-semibold mb-4">Prediction vs Actual</h2>
          <PredictionVsActual sampleId={sample.id} />
        </div>
      )}

      {/* Actions */}
      {sample.status === "ACTIVE" && (
        <div className="flex justify-end">
          <MarkAsFailedDialog
            sampleId={sample.id}
            currentDay={currentDay}
            onMarked={() => setRefresh(r => r + 1)}
          />
        </div>
      )}
    </div>
  );
}
```

### 3. `src/app/shelf-life/predictions/page.tsx`

```tsx
"use client";
import { useState } from "react";
import {
  OverpackCalculator,
  ShelfLifePredictionCard,
  WeightLossChart,
} from "../components";

export default function PredictionsPage() {
  const [prediction, setPrediction] = useState(null);
  const [inputs, setInputs] = useState({
    variety: "",
    pickTemp: "",
    brix: "",
    freightType: "AIR",
    week: "",
    packWeight: "",
  });

  async function predict() {
    const params = new URLSearchParams({
      variety: inputs.variety,
      pickTemp: inputs.pickTemp,
      brix: inputs.brix,
      freightType: inputs.freightType,
      ...(inputs.week && { week: inputs.week }),
      ...(inputs.packWeight && { packWeight: inputs.packWeight }),
    });
    const res = await fetch(`/api/shelf-life/predict/shelf-life?${params}`);
    const data = await res.json();
    setPrediction(data);
  }

  return (
    <div className="p-6 max-w-5xl mx-auto space-y-8">
      <h1 className="text-2xl font-bold">Shelf-Life Prediction & Overpack Tool</h1>

      {/* Section 1: Inputs */}
      <div className="bg-white border rounded-xl p-5 shadow-sm">
        <h2 className="text-lg font-semibold mb-4">Sample / Lot Inputs</h2>
        {/* Your input form here — or reuse OverpackCalculator's inputs */}
        <button onClick={predict}>Predict Shelf Life</button>
      </div>

      {/* Section 2: Prediction */}
      {prediction && (
        <ShelfLifePredictionCard prediction={prediction} />
      )}

      {/* Section 3: Weight Projection */}
      {prediction?.predictedWeightLoss && (
        <div className="bg-white border rounded-xl p-5 shadow-sm">
          <h2 className="text-lg font-semibold mb-4">Weight Loss Projection (40 days)</h2>
          <WeightLossChart
            readings={[]}
            predictedCurve={prediction.predictedWeightLoss.map(p => ({
              day: p.day,
              predictedLossPct: p.lossPct,
              upper95LossPct: p.upper95LossPct ?? p.lossPct * 1.2,
            }))}
          />
        </div>
      )}

      {/* Section 4: Overpack */}
      <div className="bg-white border rounded-xl p-5 shadow-sm">
        <h2 className="text-lg font-semibold mb-4">Overpack Calculator</h2>
        <OverpackCalculator />
      </div>
    </div>
  );
}
```

### 4. `src/app/shelf-life/reports/page.tsx`

```tsx
"use client";
import { useEffect, useState } from "react";
import {
  FailurePieChart,
  AvgDaysFailureChart,
  OverpackBarChart,
  TempImpactChart,
  SeasonalTrendsChart,
  VarietyIntelligenceTable,
  DataQualityPanel,
  SampleStatsCards,
} from "../components";

export default function ReportsPage() {
  const [failureData, setFailureData] = useState(null);
  const [weightData, setWeightData] = useState(null);
  const [overpackData, setOverpackData] = useState(null);
  const [tempData, setTempData] = useState(null);
  const [seasonalData, setSeasonalData] = useState(null);
  const [validationData, setValidationData] = useState(null);

  useEffect(() => {
    fetch("/api/shelf-life/reports/failure-analysis").then(r => r.json()).then(setFailureData);
    fetch("/api/shelf-life/reports/weight-retention").then(r => r.json()).then(setWeightData);
    fetch("/api/shelf-life/reports/overpack-summary").then(r => r.json()).then(setOverpackData);
    fetch("/api/shelf-life/reports/temp-impact").then(r => r.json()).then(setTempData);
    fetch("/api/shelf-life/reports/seasonal-trends").then(r => r.json()).then(setSeasonalData);
    fetch("/api/shelf-life/reports/validation").then(r => r.json()).then(setValidationData);
  }, []);

  const overpackBarData = overpackData?.map(p => ({
    variety: p.variety,
    air: p.recommendedAirOverpack,
    sea: p.recommendedSeaOverpack,
  })) || [];

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-8">
      <h1 className="text-2xl font-bold">Shelf-Life Reports</h1>

      {/* KPI Row */}
      <SampleStatsCards
        activeCount={/* from samples API */}
        failedThisWeek={/* from samples API */}
        avgShelfLife={/* calculate */}
      />

      {/* Row 2: Failure Analysis */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white border rounded-xl p-5 shadow-sm">
          <h2 className="text-lg font-semibold mb-4">Failure Reasons</h2>
          {failureData && <FailurePieChart data={failureData.failureReasons} />}
        </div>
        <div className="bg-white border rounded-xl p-5 shadow-sm">
          <h2 className="text-lg font-semibold mb-4">Avg Days to Failure</h2>
          {failureData && <AvgDaysFailureChart data={failureData.avgDaysToFailure} />}
        </div>
      </div>

      {/* Row 3: Weight + Temp */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white border rounded-xl p-5 shadow-sm">
          <h2 className="text-lg font-semibold mb-4">Weight Retention</h2>
          {/* Weight retention table */}
        </div>
        <div className="bg-white border rounded-xl p-5 shadow-sm">
          <h2 className="text-lg font-semibold mb-4">Temperature Impact</h2>
          {tempData && <TempImpactChart data={tempData} />}
        </div>
      </div>

      {/* Row 4: Seasonal + Overpack */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white border rounded-xl p-5 shadow-sm">
          <h2 className="text-lg font-semibold mb-4">Seasonal Trends</h2>
          {seasonalData && <SeasonalTrendsChart data={seasonalData} />}
        </div>
        <div className="bg-white border rounded-xl p-5 shadow-sm">
          <h2 className="text-lg font-semibold mb-4">Overpack by Variety</h2>
          {overpackBarData.length > 0 && <OverpackBarChart data={overpackBarData} />}
        </div>
      </div>

      {/* Variety Intelligence */}
      <div className="bg-white border rounded-xl p-5 shadow-sm">
        <h2 className="text-lg font-semibold mb-4">Variety Intelligence</h2>
        {overpackData && <VarietyIntelligenceTable profiles={overpackData} />}
      </div>

      {/* Data Quality */}
      <div className="bg-white border rounded-xl p-5 shadow-sm">
        <h2 className="text-lg font-semibold mb-4">Data Quality & Model Validation</h2>
        {validationData && (
          <DataQualityPanel
            totalSamples={validationData.dataQuality.totalSamples}
            issues={validationData.dataQuality.issues}
          />
        )}
        {validationData?.modelValidation?.metrics && (
          <div className="mt-4 grid grid-cols-3 gap-3">
            <div className="bg-slate-50 rounded-lg p-3 text-center">
              <p className="text-xl font-bold">{validationData.modelValidation.metrics.mae?.toFixed(1) ?? "—"}</p>
              <p className="text-xs text-gray-500">MAE (days)</p>
            </div>
            <div className="bg-slate-50 rounded-lg p-3 text-center">
              <p className="text-xl font-bold">{validationData.modelValidation.metrics.rmse?.toFixed(1) ?? "—"}</p>
              <p className="text-xs text-gray-500">RMSE (days)</p>
            </div>
            <div className="bg-slate-50 rounded-lg p-3 text-center">
              <p className="text-xl font-bold">{validationData.modelValidation.metrics.bias?.toFixed(1) ?? "—"}</p>
              <p className="text-xs text-gray-500">Bias (+ = over-predict)</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
```

## Business Rules Implemented

| Rule | Where |
|------|-------|
| Quality model: median failure day per variety, temp-adjusted, brix-adjusted, conservative P25 | `prediction.ts` |
| Weight model: day to 5% loss from variety curve | `weight-curve.ts` |
| Combined: MIN(quality, weight) | `prediction.ts` |
| Safety margin: 15% or 1 day subtracted from predicted | `prediction.ts` |
| Risk at day N: exponential decay P(failure) | `prediction.ts` |
| Confidence: HIGH (≥20 samples), MODERATE (≥8), LOW | `risk.ts` |
| KIRRA sea = HIGH RISK / 14.5% overpack | `predict/overpack` API (preserved) |
| Right-censored samples excluded from failure day calc | `prediction.ts` |
| No outcome data in prediction inputs | `prediction.ts` (only variety, temp, brix, freight) |
| Data quality: date validation, missing fields, suspicious values | `validation.ts` + `reports/validation` API |

## Files to copy

```
src/app/shelf-life/lib/
├── prediction.ts          (NEW)
├── risk.ts                (NEW)
├── weight-curve.ts        (NEW)
├── temperature.ts         (NEW)
├── validation.ts          (NEW)
└── statistics.ts          (NEW)

src/app/shelf-life/components/
├── shelf-life-prediction-card.tsx   (NEW)
├── mark-as-failed-dialog.tsx        (NEW)
├── sample-status-header.tsx         (NEW)
├── prediction-vs-actual.tsx         (NEW)
├── variety-intelligence-table.tsx   (NEW)
├── data-quality-panel.tsx           (NEW)
└── index.ts                         (UPDATE)

src/app/api/shelf-life/
├── predict/shelf-life/route.ts      (NEW)
└── reports/validation/route.ts      (NEW)
```

## Testing

1. Test prediction API:
```bash
curl "http://localhost:3000/api/shelf-life/predict/shelf-life?variety=KIRRA&pickTemp=32&brix=11.5&freightType=SEA"
```

2. Test validation report:
```bash
curl "http://localhost:3000/api/shelf-life/reports/validation"
```

3. Verify no data leakage: prediction API must NOT accept `totalDays` or `failureReason` as inputs.

4. Verify KIRRA sea still returns HIGH RISK / 14.5% overpack.
