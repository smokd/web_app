# Shelf Life Module — API Routes & Components

## Your folder structure
```
src/app/shelf-life/
├── [id]/
├── components/          ← drop components here
├── lib/
├── new/
├── predictions/
├── reports/             ← create if you don't have it
├── page.tsx             ← dashboard
```

```
src/app/api/shelf-life/  ← create this tree, drop API routes here
```

## What to copy

### 1. API Routes → `src/app/api/shelf-life/`

| File path | Route |
|-----------|-------|
| `samples/route.ts` | `GET/POST /api/shelf-life/samples` |
| `samples/[id]/route.ts` | `GET/PATCH /api/shelf-life/samples/[id]` |
| `samples/[id]/observations/route.ts` | `POST /api/shelf-life/samples/[id]/observations` |
| `samples/[id]/weight-readings/route.ts` | `POST /api/shelf-life/samples/[id]/weight-readings` |
| `predict/overpack/route.ts` | `GET /api/shelf-life/predict/overpack` |
| `reports/failure-analysis/route.ts` | `GET /api/shelf-life/reports/failure-analysis` |
| `reports/weight-retention/route.ts` | `GET /api/shelf-life/reports/weight-retention` |
| `reports/temp-impact/route.ts` | `GET /api/shelf-life/reports/temp-impact` |
| `reports/overpack-summary/route.ts` | `GET /api/shelf-life/reports/overpack-summary` |
| `reports/seasonal-trends/route.ts` | `GET /api/shelf-life/reports/seasonal-trends` |

**Note:** All API routes import Prisma from `@/lib/prisma`. If your Prisma client is elsewhere, adjust that one import line in each file.

### 2. Components → `src/app/shelf-life/components/`

All 11 components + `index.ts` barrel export. Import them in your pages like:

```tsx
import { DailyTrackingForm, WeightLossChart, StatusBadge } from "./components";
```

## How to wire into your existing pages

### `src/app/shelf-life/page.tsx` (Dashboard)

```tsx
import { SampleStatsCards, StatusBadge } from "./components";

// Fetch
const samples = await fetch("/api/shelf-life/samples").then(r => r.json());

// Stats
const activeCount = samples.filter(s => s.status === "ACTIVE").length;
const failedThisWeek = samples.filter(s => s.status === "FAILED").length;
const avgShelfLife = samples.reduce((a, s) => a + (s.totalDays || 0), 0) / samples.length || 0;

// Status logic for table
function getDisplayStatus(sample) {
  if (sample.status === "FAILED") return "FAILED";
  if (sample.status === "COMPLETED") return "COMPLETED";
  // "Approaching" = predicted failure within 2 days (implement your logic)
  return "ACTIVE";
}
```

### `src/app/shelf-life/[id]/page.tsx` (Detail / Tracking)

```tsx
import {
  DailyTrackingForm,
  WeightLossChart,
  DefectChart,
  StatusBadge,
} from "../components";

// Fetch sample + curve
const data = await fetch(`/api/shelf-life/samples/${params.id}`).then(r => r.json());
const { observations, weightReadings, weightCurve, ...sample } = data;

const existingDays = [
  ...new Set([
    ...observations.map(o => o.day),
    ...weightReadings.map(w => w.day),
  ]),
].sort((a, b) => a - b);

// Mark as Failed
async function markFailed() {
  await fetch(`/api/shelf-life/samples/${params.id}`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      status: "FAILED",
      totalDays: existingDays.length > 0 ? Math.max(...existingDays) : 0,
      failureReason: "Manually marked as failed",
    }),
  });
  router.refresh();
}
```

### `src/app/shelf-life/predictions/page.tsx`

```tsx
import { OverpackCalculator } from "../components";

export default function PredictionsPage() {
  return (
    <div className="p-6 max-w-5xl mx-auto">
      <h1 className="text-2xl font-bold mb-6">Overpack Calculator</h1>
      <OverpackCalculator />
    </div>
  );
}
```

### `src/app/shelf-life/reports/page.tsx` (create if missing)

```tsx
"use client";
import { useEffect, useState } from "react";
import {
  FailurePieChart,
  AvgDaysFailureChart,
  OverpackBarChart,
  TempImpactChart,
  SeasonalTrendsChart,
} from "../components";

// Fetch each report section in useEffect:
//   /api/shelf-life/reports/failure-analysis
//   /api/shelf-life/reports/weight-retention
//   /api/shelf-life/reports/overpack-summary
//   /api/shelf-life/reports/temp-impact
//   /api/shelf-life/reports/seasonal-trends

// Overpack bar data shape:
const overpackBarData = overpackData.map(p => ({
  variety: p.variety,
  air: p.recommendedAirOverpack,
  sea: p.recommendedSeaOverpack,
}));
```

## Business rules already implemented

| Rule | Where |
|------|-------|
| Auto-calculate `weightLossPct` | `weight-readings` API |
| Auto-flag abnormal (single-day loss >5% or weight up >2%) | `weight-readings` API |
| Suggest FAIL if defects >3 or shrivel >5 | `observations` API + `DailyTrackingForm` |
| Overpack formula | `predict/overpack` API |
| Temp >30°C = +0.15%/°C, >35°C = +0.25%/°C | `predict/overpack` API |
| Week 27+ = +1.5%, Week 31+ = +2.5% | `predict/overpack` API |
| Brix <10.5 = +1% | `predict/overpack` API |
