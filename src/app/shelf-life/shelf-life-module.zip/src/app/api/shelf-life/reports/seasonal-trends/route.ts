import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function GET(req: NextRequest) {
  try {
    const samples = await prisma.shelfLifeSample.findMany({
      where: { week: { not: null }, status: { not: null } },
      select: { week: true, variety: true, totalDays: true, status: true },
    });

    const weekData: Record<number, { total: number; count: number; failed: number }> = {};
    samples.forEach((s) => {
      const w = s.week!;
      if (!weekData[w]) weekData[w] = { total: 0, count: 0, failed: 0 };
      weekData[w].total += s.totalDays || 0;
      weekData[w].count += 1;
      if (s.status === 'FAILED') weekData[w].failed += 1;
    });

    const trends = Object.entries(weekData)
      .map(([week, data]) => ({
        week: parseInt(week),
        avgShelfLife: parseFloat((data.total / data.count).toFixed(1)),
        sampleCount: data.count,
        failureRate: parseFloat(((data.failed / data.count) * 100).toFixed(1)),
      }))
      .sort((a, b) => a.week - b.week);

    return NextResponse.json(trends);
  } catch (error) {
    console.error('GET seasonal-trends error:', error);
    return NextResponse.json({ error: 'Failed to fetch trends' }, { status: 500 });
  }
}
