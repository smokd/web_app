import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function GET(req: NextRequest) {
  try {
    const failedSamples = await prisma.shelfLifeSample.findMany({
      where: { status: 'FAILED' },
      include: { observations: true },
    });

    const reasonCounts: Record<string, number> = {};
    failedSamples.forEach((s) => {
      const reason = s.failureReason || 'Unknown';
      reasonCounts[reason] = (reasonCounts[reason] || 0) + 1;
    });
    const failureReasons = Object.entries(reasonCounts).map(([name, value]) => ({ name, value }));

    const varietyDays: Record<string, { total: number; count: number }> = {};
    failedSamples.forEach((s) => {
      if (!varietyDays[s.variety]) varietyDays[s.variety] = { total: 0, count: 0 };
      varietyDays[s.variety].total += s.totalDays || 0;
      varietyDays[s.variety].count += 1;
    });
    const avgDaysToFailure = Object.entries(varietyDays).map(([variety, data]) => ({
      variety,
      avgDays: parseFloat((data.total / data.count).toFixed(1)),
      count: data.count,
    }));

    const failedTable = failedSamples.map((s) => ({
      id: s.id,
      sampleId: s.sampleId,
      variety: s.variety,
      type: s.sampleType,
      totalDays: s.totalDays,
      failureReason: s.failureReason,
      pickDate: s.pickDate,
      freightType: s.freightType,
    }));

    return NextResponse.json({
      totalFailed: failedSamples.length,
      failureReasons,
      avgDaysToFailure,
      failedTable,
    });
  } catch (error) {
    console.error('GET failure-analysis error:', error);
    return NextResponse.json({ error: 'Failed to generate report' }, { status: 500 });
  }
}
