import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function GET(req: NextRequest) {
  try {
    const impacts = await prisma.shelfLifeTempImpact.findMany({
      orderBy: { avgShelfLife: 'desc' },
    });
    return NextResponse.json(impacts);
  } catch (error) {
    console.error('GET temp-impact error:', error);
    return NextResponse.json({ error: 'Failed to fetch temp impact' }, { status: 500 });
  }
}
