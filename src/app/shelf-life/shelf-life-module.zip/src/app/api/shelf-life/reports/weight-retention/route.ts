import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function GET(req: NextRequest) {
  try {
    const samples = await prisma.shelfLifeSample.findMany({
      where: { sampleType: 'WEIGHT_RETENTION' },
      include: { weightReadings: { orderBy: { day: 'asc' } } },
    });

    const summaries = samples.map((s) => {
      const readings = s.weightReadings;
      const day5 = readings.find((r) => r.weightLossPct && r.weightLossPct >= 5)?.day || null;
      const day10 = readings.find((r) => r.weightLossPct && r.weightLossPct >= 10)?.day || null;
      const maxLoss = readings.length > 0
        ? Math.max(...readings.map((r) => r.weightLossPct || 0))
        : 0;
      const finalDay = readings.length > 0 ? readings[readings.length - 1].day : 0;

      return {
        id: s.id,
        sampleId: s.sampleId,
        variety: s.variety,
        packWeight: s.packWeight,
        daysTracked: finalDay,
        maxLossPct: parseFloat(maxLoss.toFixed(2)),
        daysTo5PctLoss: day5,
        daysTo10PctLoss: day10,
        abnormalReadings: readings.filter((r) => r.abnormal).length,
      };
    });

    return NextResponse.json(summaries);
  } catch (error) {
    console.error('GET weight-retention report error:', error);
    return NextResponse.json({ error: 'Failed to generate report' }, { status: 500 });
  }
}
