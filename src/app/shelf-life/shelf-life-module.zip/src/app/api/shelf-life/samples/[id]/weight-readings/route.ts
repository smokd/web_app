import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function POST(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const body = await req.json();
    const day = parseInt(body.day);
    const weightGrams = parseFloat(body.weightGrams);

    const sample = await prisma.shelfLifeSample.findUnique({
      where: { id: params.id },
      select: { packWeight: true },
    });

    const packWeight = sample?.packWeight ?? 0;
    const weightLossPct = packWeight > 0 ? ((packWeight - weightGrams) / packWeight) * 100 : null;

    const prev = await prisma.shelfLifeWeightReading.findFirst({
      where: { sampleId: params.id, day: { lt: day } },
      orderBy: { day: 'desc' },
    });
    const lossRatePctDay = prev && prev.weightGrams > 0
      ? ((prev.weightGrams - weightGrams) / prev.weightGrams) * 100
      : null;

    const abnormal = (lossRatePctDay !== null && lossRatePctDay > 5) ||
                     (prev && weightGrams > prev.weightGrams * 1.02);

    const reading = await prisma.shelfLifeWeightReading.create({
      data: {
        sampleId: params.id,
        day,
        weightGrams,
        weightLossPct,
        lossRatePctDay,
        abnormal,
      },
    });

    await prisma.shelfLifeSample.update({
      where: { id: params.id },
      data: { totalDays: { set: day } },
    });

    return NextResponse.json(reading, { status: 201 });
  } catch (error) {
    console.error('POST weight-reading error:', error);
    return NextResponse.json({ error: 'Failed to create weight reading' }, { status: 500 });
  }
}
