import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function POST(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const body = await req.json();
    const shrivel = parseInt(body.shrivelCount || '0');
    const soft = parseInt(body.softCount || '0');
    const collapsed = parseInt(body.collapsedCount || '0');
    const totalDefects = shrivel + soft + collapsed;

    let overallStatus = body.overallStatus || 'GOOD';
    if (!body.overallStatus) {
      if (totalDefects > 3 || shrivel > 5) overallStatus = 'FAIL';
      else if (totalDefects > 0) overallStatus = 'FAIR';
    }

    const observation = await prisma.shelfLifeObservation.create({
      data: {
        sampleId: params.id,
        day: parseInt(body.day),
        shrivelCount: shrivel,
        softCount: soft,
        collapsedCount: collapsed,
        otherDefects: body.otherDefects || null,
        overallStatus,
        totalDefects,
        notes: body.notes || null,
      },
    });

    await prisma.shelfLifeSample.update({
      where: { id: params.id },
      data: { totalDays: { set: parseInt(body.day) } },
    });

    return NextResponse.json(observation, { status: 201 });
  } catch (error) {
    console.error('POST observations error:', error);
    return NextResponse.json({ error: 'Failed to create observation' }, { status: 500 });
  }
}
