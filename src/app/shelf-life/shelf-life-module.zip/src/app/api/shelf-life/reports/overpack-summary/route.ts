import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function GET(req: NextRequest) {
  try {
    const profiles = await prisma.shelfLifeVarietyProfile.findMany({
      orderBy: { variety: 'asc' },
      select: {
        variety: true,
        recommendedAirOverpack: true,
        recommendedSeaOverpack: true,
        riskLevelAir: true,
        riskLevelSea: true,
      },
    });
    return NextResponse.json(profiles);
  } catch (error) {
    console.error('GET overpack-summary error:', error);
    return NextResponse.json({ error: 'Failed to fetch overpack data' }, { status: 500 });
  }
}
