import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const variety = searchParams.get('variety');
    const temp = parseFloat(searchParams.get('pickTemp') || '0');
    const freight = searchParams.get('freightType') || 'AIR';
    const week = parseInt(searchParams.get('week') || '0');
    const brix = parseFloat(searchParams.get('brix') || '0');
    const shipmentWeight = parseFloat(searchParams.get('shipmentWeight') || '1000');

    if (!variety) {
      return NextResponse.json({ error: 'Variety is required' }, { status: 400 });
    }

    const profile = await prisma.shelfLifeVarietyProfile.findUnique({
      where: { variety },
    });

    if (!profile) {
      return NextResponse.json({ error: 'Variety profile not found' }, { status: 404 });
    }

    const baseOverpack = freight === 'SEA'
      ? (profile.recommendedSeaOverpack ?? 5)
      : (profile.recommendedAirOverpack ?? 3);

    const riskLevel = freight === 'SEA'
      ? (profile.riskLevelSea || 'LOW RISK')
      : (profile.riskLevelAir || 'LOW RISK');

    let tempAdjustment = 0;
    if (temp > 35) tempAdjustment = (temp - 35) * 0.25;
    else if (temp > 30) tempAdjustment = (temp - 30) * 0.15;

    let seasonAdjustment = 0;
    if (week >= 31) seasonAdjustment = 2.5;
    else if (week >= 27) seasonAdjustment = 1.5;

    let brixAdjustment = 0;
    if (brix > 0 && brix < 10.5) brixAdjustment = 1.0;

    const recommendedOverpack = baseOverpack + tempAdjustment + seasonAdjustment + brixAdjustment;
    const kgToAdd = (shipmentWeight * recommendedOverpack) / 100;
    const flatRate = freight === 'SEA' ? 8 : 5;
    const flatKg = (shipmentWeight * flatRate) / 100;

    return NextResponse.json({
      variety,
      freightType: freight,
      baseOverpack,
      tempAdjustment: parseFloat(tempAdjustment.toFixed(2)),
      seasonAdjustment,
      brixAdjustment,
      recommendedOverpack: parseFloat(recommendedOverpack.toFixed(2)),
      riskLevel,
      kgToAdd: parseFloat(kgToAdd.toFixed(2)),
      shipmentWeight,
      flatRate,
      flatKg: parseFloat(flatKg.toFixed(2)),
      extraVsFlat: parseFloat((kgToAdd - flatKg).toFixed(2)),
      warnings: {
        highTemp: temp > 30,
        veryHighTemp: temp > 35,
        lowBrix: brix > 0 && brix < 10.5,
        lateSeason: week >= 27,
        veryLateSeason: week >= 31,
      },
    });
  } catch (error) {
    console.error('GET predict/overpack error:', error);
    return NextResponse.json({ error: 'Failed to calculate overpack' }, { status: 500 });
  }
}
