import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function GET(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const sample = await prisma.shelfLifeSample.findUnique({
      where: { id: params.id },
      include: {
        observations: { orderBy: { day: 'asc' } },
        weightReadings: { orderBy: { day: 'asc' } },
      },
    });

    if (!sample) {
      return NextResponse.json({ error: 'Sample not found' }, { status: 404 });
    }

    const weightCurve = await prisma.shelfLifeWeightCurve.findMany({
      where: { variety: sample.variety },
      orderBy: { day: 'asc' },
    });

    return NextResponse.json({ ...sample, weightCurve });
  } catch (error) {
    console.error('GET /api/shelf-life/samples/[id] error:', error);
    return NextResponse.json({ error: 'Failed to fetch sample' }, { status: 500 });
  }
}

export async function PATCH(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const body = await req.json();
    const sample = await prisma.shelfLifeSample.update({
      where: { id: params.id },
      data: {
        status: body.status,
        failureReason: body.failureReason ?? undefined,
        totalDays: body.totalDays ?? undefined,
        notes: body.notes ?? undefined,
      },
    });
    return NextResponse.json(sample);
  } catch (error) {
    console.error('PATCH /api/shelf-life/samples/[id] error:', error);
    return NextResponse.json({ error: 'Failed to update sample' }, { status: 500 });
  }
}
