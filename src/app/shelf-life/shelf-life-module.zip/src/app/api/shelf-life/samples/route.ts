import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const status = searchParams.get('status');
    const variety = searchParams.get('variety');
    const type = searchParams.get('type');
    const search = searchParams.get('search');

    const where: any = {};
    if (status && status !== 'ALL') where.status = status;
    if (variety && variety !== 'ALL') where.variety = variety;
    if (type && type !== 'ALL') where.sampleType = type;
    if (search) {
      where.OR = [
        { sampleId: { contains: search, mode: 'insensitive' } },
        { variety: { contains: search, mode: 'insensitive' } },
        { customer: { contains: search, mode: 'insensitive' } },
      ];
    }

    const samples = await prisma.shelfLifeSample.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      include: {
        observations: { orderBy: { day: 'asc' } },
        weightReadings: { orderBy: { day: 'asc' } },
        _count: { select: { observations: true, weightReadings: true } },
      },
    });

    const enriched = samples.map((s) => {
      const daysTracked = Math.max(
        ...s.observations.map((o) => o.day),
        ...s.weightReadings.map((w) => w.day),
        0
      );
      return { ...s, daysTracked };
    });

    return NextResponse.json(enriched);
  } catch (error) {
    console.error('GET /api/shelf-life/samples error:', error);
    return NextResponse.json({ error: 'Failed to fetch samples' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const sample = await prisma.shelfLifeSample.create({
      data: {
        sampleId: body.sampleId || `SMP-${Date.now()}`,
        sampleType: body.sampleType,
        variety: body.variety,
        fruitSize: body.fruitSize ? parseInt(body.fruitSize) : null,
        lCode: body.lCode || null,
        block: body.block || null,
        pickDate: body.pickDate || null,
        pickTemp: body.pickTemp ? parseFloat(body.pickTemp) : null,
        packDate: body.packDate || null,
        brix: body.brix ? parseFloat(body.brix) : null,
        freightType: body.freightType || null,
        customer: body.customer || null,
        palletCode: body.palletCode || null,
        week: body.week ? parseInt(body.week) : null,
        moisturePct: body.moisturePct ? parseFloat(body.moisturePct) : null,
        packWeight: body.packWeight ? parseFloat(body.packWeight) : null,
        targetTemp: body.targetTemp ? parseFloat(body.targetTemp) : 5.0,
        status: 'ACTIVE',
        notes: body.notes || null,
      },
    });
    return NextResponse.json(sample, { status: 201 });
  } catch (error) {
    console.error('POST /api/shelf-life/samples error:', error);
    return NextResponse.json({ error: 'Failed to create sample' }, { status: 500 });
  }
}
